Description: replicate the find and grep functions

Code base: c