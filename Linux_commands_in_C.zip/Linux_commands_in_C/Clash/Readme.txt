Description: clash.c implements several unix commands
		plist.c implements background processes management function

Code base: c