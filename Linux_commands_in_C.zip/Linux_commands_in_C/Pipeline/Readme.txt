Description: ticker.c implements signal functions 
	     concat.c implements several unix commands sequentially

Code base: c