package GUI;

//Coordinates in double. Might be useful later
public class Vector2dDouble {
    private double x;
    private double y;

    public Vector2dDouble() {}

    public Vector2dDouble(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}
