package GUI;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.LinkedList;
//import java.util.Random;

public class Guest {
	public static final int BOARD_DIM = 10;
	private static Board allieBoard = new Board(BOARD_DIM);
	private static Board enemyBoard = new Board(BOARD_DIM);
	private static BoardUI allieBoardUI;
	private static BoardUI enemyBoardUI;
	//    private GUI.ShipUI shipUI = new GUI.ShipUI();
	private static Group root = new Group();
	private static Pane leftShipContainer = new Pane();
	private static Pane rightShipContainer = new Pane();
	public LinkedList<ShipUI> shipUIList = new LinkedList<>();
	private TextArea chatBox = new TextArea();
	private TextField input = new TextField();
	private Group buttons = new Group();
	private Button nextBTN = new Button("Next -->");
	private Group LnNA = new Group();
	private Group LnNB = new Group();
	private static Text HostName = new Text("Name here");
	private static Text GuestName = new Text("Name here");
	private Text greet = new Text("--------THE WAR BEGINS--------");
	private Text greet2 = new Text("GOOD LUCK");
	private Text message = new Text("Take Down the Enemy Fleet"+"\n"+"    Before They Take YOURS");
	Button btn1 = new Button("Thanks");
	Button btn2 = new Button("Good game");
	Button btn3 = new Button("Good luck");
	Button btn4 = new Button("Well played");

	public Guest() {
		root.getChildren().addAll(leftShipContainer, rightShipContainer,chatBox,input,nextBTN,HostName,GuestName);
	}

	public void init(Scene scene) {		
		//Name from host
		HostName.setFont(Font.font("Copperplate Gothic Light", 40));
		HostName.setFill(Color.web("#D35400"));
		final double nameWidth = HostName.getLayoutBounds().getWidth();		
		HostName.setTranslateX((568-nameWidth)/2);
		HostName.setTranslateY(40);		
		
		//Name from guest
		GuestName.setFont(Font.font("Copperplate Gothic Light", HostName.getFont().getSize()));
		GuestName.setFill(Color.web("#D35400"));
		GuestName.setTranslateX(568+(568-nameWidth)/2);
		GuestName.setTranslateY(40);

		//Chatbox
		chatBox.setMaxSize(400, 650);
		chatBox.setMinSize(400, 650);
		chatBox.setTranslateX(scene.getWidth()-chatBox.getMaxWidth()-2);
		chatBox.setTranslateY(0);
		chatBox.setEditable(false);     
		chatBox.setStyle("-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-radius: 5;" +
				"-fx-text-fill: #43C6DB;" +
				"-fx-focus-color: transparent;" +
				"-fx-faint-focus-color: transparent;" +
				"-fx-border-color: #48CCCD;");     
		chatBox.setFont(Font.font("Titillium Web", 20));

		input.setMaxSize(chatBox.getMaxWidth(), 50);
		input.setMinSize(chatBox.getMinWidth(), 50);
		input.setTranslateX(chatBox.getTranslateX());
		input.setTranslateY(chatBox.getTranslateY()+chatBox.getMaxHeight());
		input.setStyle("-fx-border-width: 2;" +
				"-fx-border-radius: 5;" +
				"-fx-focus-color: transparent;" +
				"-fx-faint-focus-color: transparent;" +
				"-fx-border-color: #48CCCD;");
		input.setFont(Font.font("Titillium Web", 20));
		input.addEventHandler(KeyEvent.KEY_PRESSED,new EventHandler<KeyEvent>(){

			@Override
			public void handle(KeyEvent key) {
				if(key.getCode() == KeyCode.ENTER) {
					//					String message = isHost ? "Player 1: " : "Player 2: ";
					chatBox.appendText(input.getText()+ "\n");
					input.clear();
				}

			}

		});        

		btn1.setPrefSize(input.getMaxWidth()/2, (scene.getHeight()-(input.getTranslateY()+input.getMaxHeight()))/3);
		btn1.setTranslateX(input.getTranslateX());
		btn1.setTranslateY(input.getTranslateY()+input.getMaxHeight());
		btn1.setStyle("-fx-background-color: #FEFCFF;"+
				"-fx-border-width: 2;"+
				"-fx-border-radius: 5;" +
				"-fx-border-color: #4285F4;");
		btn1.setFont(Font.font("Titillium Web", 20));
		btn1.setTextFill(Color.web("#4285F4"));

		btn2.setPrefSize(input.getMaxWidth()/2, btn1.getPrefHeight());
		btn2.setTranslateX(input.getTranslateX()+input.getMaxWidth()/2);
		btn2.setTranslateY(btn1.getTranslateY());
		btn2.setStyle("-fx-background-color: #FEFCFF;"+
				"-fx-border-width: 2;"+
				"-fx-border-radius: 5;" +
				"-fx-border-color: #DB4437;");
		btn2.setFont(Font.font("Titillium Web", btn1.getFont().getSize()));
		btn2.setTextFill(Color.web("#DB4437"));

		btn3.setPrefSize(input.getMaxWidth()/2, btn1.getPrefHeight());
		btn3.setTranslateX(btn1.getTranslateX());
		btn3.setTranslateY(btn1.getTranslateY()+btn1.getPrefHeight());
		btn3.setStyle("-fx-background-color: #FEFCFF;"+
				"-fx-border-width: 2;"+
				"-fx-border-radius: 5;" +
				"-fx-border-color: #F4B400;");
		btn3.setFont(Font.font("Titillium Web", btn1.getFont().getSize()));
		btn3.setTextFill(Color.web("#F4B400"));

		btn4.setPrefSize(input.getMaxWidth()/2, btn1.getPrefHeight());
		btn4.setTranslateX(btn2.getTranslateX());
		btn4.setTranslateY(btn2.getTranslateY()+btn2.getPrefHeight());
		btn4.setStyle("-fx-background-color: #FEFCFF;"+
				"-fx-border-width: 2;"+
				"-fx-border-radius: 5;" +
				"-fx-border-color: #0F9D58;");
		btn4.setFont(Font.font("Titillium Web", btn1.getFont().getSize()));
		btn4.setTextFill(Color.web("#0F9D58"));

		nextBTN.setPrefSize(btn1.getPrefWidth()*2, btn1.getPrefHeight());
		nextBTN.setTranslateX(btn1.getTranslateX());
		nextBTN.setTranslateY(btn3.getTranslateY()+btn3.getPrefHeight());
		nextBTN.setStyle("-fx-background-color: #43BFC7;" + "-fx-border-radius: 5;");
		nextBTN.setFont(Font.font("Titillium Web", btn1.getFont().getSize()));
		nextBTN.setTextFill(Color.WHITE);

		buttons.getChildren().addAll(btn1,btn2,btn3,btn4); 
		for(int x = 0; x < 4; x++) {
			((Button)buttons.getChildren().get(x)).setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent a) {
					String text = ((Button)a.getSource()).getText();
					chatBox.appendText(text+"\n");
				}

			});
		}

		//Creating boards 
		
		//Ally board 
		allieBoardUI = BoardUI.drawBoard(allieBoard, Color.web("#EAECEE"),BoardUI.getBlockSize());
		allieBoardUI.checkShot(BOARD_DIM, allieBoard);
		allieBoardUI.setTranslateX((chatBox.getTranslateX()/2 - BoardUI.getBlockSize()*BOARD_DIM)/2);
		allieBoardUI.setTranslateY(64);
		LnNA = BoardUI.drawUI(allieBoardUI.getTranslateX(),allieBoardUI.getTranslateY(),BOARD_DIM,BoardUI.getBlockSize());

		//Enemy board
		enemyBoardUI = BoardUI.drawBoard(enemyBoard, Color.web("#EAECEE"),BoardUI.getBlockSize());
		enemyBoardUI.checkShot(BOARD_DIM, enemyBoard);
		enemyBoardUI.setTranslateX(chatBox.getTranslateX()/2 + (chatBox.getTranslateX()/2 - BoardUI.getBlockSize()*BOARD_DIM)/2);
		enemyBoardUI.setTranslateY(64);
		LnNB = BoardUI.drawUI(enemyBoardUI.getTranslateX(),enemyBoardUI.getTranslateY(),BOARD_DIM,BoardUI.getBlockSize());	

		//Container of ships on the left
		leftShipContainer.setPrefSize(chatBox.getTranslateX()/2-3, scene.getHeight()-(allieBoardUI.getTranslateY()+BoardUI.getBlockSize()*BOARD_DIM+11));
		leftShipContainer.setStyle("-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-radius: 10;" +
				"-fx-border-color: #FBB917;");
		leftShipContainer.setTranslateX(0);
		leftShipContainer.setTranslateY(allieBoardUI.getTranslateY()+BoardUI.getBlockSize()*BOARD_DIM+11);
		

		//Container of ships on the right
		rightShipContainer.setPrefSize(leftShipContainer.getPrefWidth(), leftShipContainer.getPrefHeight());
		rightShipContainer.setStyle("-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-radius: 10;" +
				"-fx-border-color: #FBB917;");
		rightShipContainer.setTranslateX(leftShipContainer.getTranslateX()+leftShipContainer.getPrefWidth()+2);
		rightShipContainer.setTranslateY(leftShipContainer.getTranslateY());	
		greet.setFont(Font.font("Impact", 50));		
		greet.setFill(Color.web("#b80f0a"));
		greet.setTranslateX(1);
		greet.setTranslateY(52);
		greet2.setFont(Font.font("Titillium Web", 40));
		final double greetWidth = greet2.getLayoutBounds().getWidth();
		greet2.setFill(Color.web("#b80f0a"));
		greet2.setTranslateX((rightShipContainer.getPrefWidth()-greetWidth)/2);
		greet2.setTranslateY(rightShipContainer.getPrefHeight()-5);
		message.setFont(Font.font("Bell MT",30));
		final double messageWidth = message.getLayoutBounds().getWidth();
		message.setFill(Color.web("#4682B4"));
		message.setTranslateX((rightShipContainer.getPrefWidth()-messageWidth)/2);
		message.setTranslateY(rightShipContainer.getPrefHeight()/2-7);
		rightShipContainer.getChildren().addAll(greet, greet2, message);	

		root.getChildren().addAll(allieBoardUI, enemyBoardUI,buttons,LnNA,LnNB);
	}

	public static Text getHostName() {
		return HostName;
	}

	public static Text getGuestName() {
		return GuestName;
	}

	public static Pane getLeftContainer() {
		return leftShipContainer;
	}

	public static Pane getRightContainer() {
		return rightShipContainer;
	}

	public static BoardUI getallieBoardUI(){
		return allieBoardUI;
	}

	public static BoardUI getenemyBoardUI(){
		return enemyBoardUI;
	}

	public static Board getallieBoard() {
		return allieBoard;
	}

	public static Board getenemyBoard() {
		return enemyBoard;
	}

	public Button getNextBTN() {
		return nextBTN;
	}

	public static Group getRoot() {
		return root;
	}
}
