package GUI;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
public class StartPage {
	public static Group group = new Group();
	public Text head = new Text("Battleship Game");
	public Text or = new Text("or");
	public Button host = new Button("HOST");
	public Button guest = new Button("GUEST");
	
	public StartPage() {
		group.getChildren().addAll(head,guest,host,or);
	}
	
	public void set(Scene scene) {
		head.setFill(Color.web("#FFA62F"));		
		Font font = Font.font("Candara Light", 50); 
		head.setFont(font);
		final double headWidth = head.getLayoutBounds().getWidth();		
		head.setTranslateX((scene.getWidth() - headWidth)/2);
		head.setTranslateY(140);
		
		host.setStyle("-fx-background-color: #38ACEC;"+
						"-fx-border-width: 2;" +
		                "-fx-border-radius: 5;" +
		                "-fx-text-fill: #FBFCFC;");
		host.setFont(Font.font("Bell MT", 25));
		host.setPrefSize(120,30);
		host.setTranslateX(head.getTranslateX());
		host.setTranslateY(head.getTranslateY()+20);
		
		guest.setStyle("-fx-background-color: #F62217;"+
						"-fx-border-width: 2;" +
		                "-fx-border-radius: 5;" +
		                "-fx-text-fill: #FBFCFC;");
		guest.setFont(Font.font("Bell MT", 25));
		guest.setPrefSize(120,30);
		guest.setTranslateX(head.getTranslateX() + headWidth - guest.getPrefWidth());
		guest.setTranslateY(head.getTranslateY()+20);
		
		or.setFont(Font.font("Leelawadee UI Semilight", 25));
		double orWidth = or.getLayoutBounds().getWidth();
		double orHeight = or.getLayoutBounds().getWidth();
		or.setFill(Color.web("#17c7d7"));
		or.setTranslateX((scene.getWidth() - orWidth)/2);
		or.setTranslateY(host.getTranslateY() + (host.getPrefHeight()+orHeight)/2);
	}
	
	public Button getHostBTN() {
		return host;
	}
	
	public Button getGuestBTN() {
		return guest;
	}
	
	public Group getGroup() {
		return group;
	}
	
}
