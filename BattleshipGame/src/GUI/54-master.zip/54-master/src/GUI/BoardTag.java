package GUI;

//Tags that assign the state a cell is in, whether empty, occupied by ships or occupied by a wrecked ship
public enum BoardTag {
    EMPTY,		//Empty
    BRIG,		//Ship
    WRECKED		//shot
}
