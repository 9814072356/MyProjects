package GUI;

public class Board {
    public BoardTag[][] cells; //Condition of every cell on the board(ship, wrecked, empty)
    private static int dim;
    //Create an NxN board
    Board(int dim) {
        this.dim = dim;
        cells = new BoardTag[dim][dim];
        for(int row = 0; row < dim; row++) {
            for(int col = 0; col < dim; col++) {
                cells[row][col] = BoardTag.EMPTY;
            }
        }
    }

    public static int getDim() {
        return dim;
    }
    
    public void setCell(int row, int col, BoardTag tag) {
    	if(row < this.dim && col < this.dim)
    	    cells[row][col] = tag;
    }

    public BoardTag getCell(int row, int col) {
        if(row < this.dim && col < this.dim)
            return cells[row][col];
        else
            return null;
    }
}
