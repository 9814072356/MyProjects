package GUI;

import java.util.LinkedList;
import java.util.Random;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Host_preGame {
	public static final int BOARD_DIM = 10;
	public static final int BLOCK_SIZE = 25;
	public static final int SHIP_BLOCK_SIZE = 15;
    private static final int SHIP_QUANTITY_5 = 1;
    private static final int SHIP_QUANTITY_4 = 1;
    private static final int SHIP_QUANTITY_3 = 3;
    private static final int SHIP_QUANTITY_2 = 3;
    private static final int SHIP_QUANTITY_1 = 2;
	private BoardUI boardUI;
	private static Board board;
	private Pane shipContainer;
	private Pane info;
	private static Group root;
	private Group LnN;
	private ShipUI shipUI;
	private Group ShipGroup;
    public static LinkedList<ShipUI> shipUIList;  //ship list --> game logic, determines which ship is still on the board
    private Text rule = new Text("*SHIPS MUST BE ONE BLOCK APART");
    private Text greet = new Text("Welcome to Battleship");
    private Button message = new Button("Click THIS to Continue");
	
	public void set() {
		shipContainer = new Pane();
		info = new Pane();
		root = new Group();
		board = new Board(BOARD_DIM);
		shipUI = new ShipUI();
		ShipGroup = new Group();
        shipUIList = new LinkedList<>();      
       		
		boardUI = BoardUI.drawBoard(board, Color.web("#EAECEE"),25);
        boardUI.setTranslateX(15);
        boardUI.setTranslateY(15);
        LnN = new Group();
        LnN = BoardUI.drawUI(boardUI.getTranslateX(),boardUI.getTranslateY(),BOARD_DIM,BLOCK_SIZE);
        
        info.setPrefSize(275, 200);
        info.setStyle("-fx-border-style: solid inside;" +
					        		"-fx-border-width: 2;" +
					        		"-fx-border-radius: 5;" +
					        		"-fx-border-color: orange;");
        info.setTranslateX(5);
        info.setTranslateY(280);
        greet.setFont(Font.font("Impact", 28));
        greet.setFill(Color.web("#D35400"));
        greet.setTranslateX(8);
        greet.setTranslateY(30);
        rule.setFont(Font.font("Bell MT", 12));
        rule.setFill(Color.web("#4682B4"));
        rule.setTranslateX(32);
        rule.setTranslateY(45);
        message.setFont(Font.font("Impact",18));
        message.setStyle("-fx-border-color: transparent;"+
        				 "-fx-background-color: transparent;");
        message.setTextFill(Color.web("#4682B4"));
        message.setTranslateX(info.getPrefWidth()/2-82);
        message.setTranslateY(info.getPrefHeight()/2-9);
        info.getChildren().addAll(rule,greet,message);
        
        shipContainer.setTranslateX(boardUI.getTranslateX()+250+20);
        shipContainer.setTranslateY(boardUI.getTranslateY());
        shipContainer.setPrefSize(210,465);
        shipContainer.setStyle("-fx-border-style: solid inside;" +
        		"-fx-border-width: 2;" +
        		"-fx-border-radius: 5;" +
        		"-fx-border-color: orange;");
        
        //Position of ships in container
        double tileX = shipContainer.getTranslateX();
        double tileY = shipContainer.getTranslateY();
        double lastCol = tileX + shipContainer.getPrefWidth();    
        
        //Making ships
        for (int i = 0; i < SHIP_QUANTITY_5; i++) {
        	Random r = new Random();
            ShipUI ship = shipUI.createShip(5,true,10);
        	if(tileX >= lastCol) {
        		tileX = shipContainer.getTranslateX();
        		tileY += shipContainer.getPrefHeight()/5;
        	}
        	
        	ship.setTranslateX(tileX + shipContainer.getPrefWidth()/8);
        	ship.setTranslateY(tileY + shipContainer.getPrefHeight()/25);
        	

            ShipGroup.getChildren().add(ship);
        	tileX += shipContainer.getPrefWidth()/2;
            ship.addDragAndDrop(board,boardUI,shipContainer,shipContainer.getTranslateX(),shipContainer.getTranslateY());
            shipUIList.add(ship);
        }
        for (int i = 0; i < SHIP_QUANTITY_4; i++) {
        	Random r = new Random();
            ShipUI ship = shipUI.createShip(4,true,10);
        	if(tileX >= lastCol) {
        		tileX = shipContainer.getTranslateX();
        		tileY += shipContainer.getPrefHeight()/5;
        	}
        	
        	ship.setTranslateX(tileX + shipContainer.getPrefWidth()/8);
        	ship.setTranslateY(tileY + shipContainer.getPrefHeight()/25);
        	

        	ShipGroup.getChildren().add(ship);
        	tileX += shipContainer.getPrefWidth()/2;
            ship.addDragAndDrop(board,boardUI,shipContainer,shipContainer.getTranslateX(),shipContainer.getTranslateY());
            shipUIList.add(ship);
        }
        for (int i = 0; i < SHIP_QUANTITY_3; i++) {
        	Random r = new Random();
            ShipUI ship = shipUI.createShip(3,true,10);
        	if(tileX >= lastCol) {
        		tileX = shipContainer.getTranslateX();
        		tileY += shipContainer.getPrefHeight()/5;
        	}
        	
        	ship.setTranslateX(tileX + shipContainer.getPrefWidth()/8);
        	ship.setTranslateY(tileY + shipContainer.getPrefHeight()/25);
        	

        	ShipGroup.getChildren().add(ship);
        	tileX += shipContainer.getPrefWidth()/2;
            ship.addDragAndDrop(board,boardUI,shipContainer,shipContainer.getTranslateX(),shipContainer.getTranslateY());
            shipUIList.add(ship);
        }
        for (int i = 0; i < SHIP_QUANTITY_2; i++) {
        	Random r = new Random();
            ShipUI ship = shipUI.createShip(2,true,10);
        	if(tileX >= lastCol) {
        		tileX = shipContainer.getTranslateX();
        		tileY += shipContainer.getPrefHeight()/5;
        	}
        	
        	ship.setTranslateX(tileX + shipContainer.getPrefWidth()/8);
        	ship.setTranslateY(tileY + shipContainer.getPrefHeight()/25);
        	

        	ShipGroup.getChildren().add(ship);
        	tileX += shipContainer.getPrefWidth()/2;
            ship.addDragAndDrop(board,boardUI,shipContainer,shipContainer.getTranslateX(),shipContainer.getTranslateY());
            shipUIList.add(ship);
        }
        for (int i = 0; i < SHIP_QUANTITY_1; i++) {
        	Random r = new Random();
            ShipUI ship = shipUI.createShip(1,true,10);
        	if(tileX >= lastCol) {
        		tileX = shipContainer.getTranslateX();
        		tileY += shipContainer.getPrefHeight()/5;
        	}
        	
        	ship.setTranslateX(tileX + shipContainer.getPrefWidth()/8);
        	ship.setTranslateY(tileY + shipContainer.getPrefHeight()/25);
        	

        	ShipGroup.getChildren().add(ship);
        	tileX += shipContainer.getPrefWidth()/2;
            ship.addDragAndDrop(board,boardUI,shipContainer,shipContainer.getTranslateX(),shipContainer.getTranslateY());
            shipUIList.add(ship);
        }
        
        root.getChildren().addAll(boardUI,info,LnN,shipContainer,ShipGroup);
	}
	
	//Change to next screen
	public void changeScreen(Stage stage, Scene toChange) {		
		message.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				int counter = 0;
				for(int row = 0; row < BOARD_DIM; row++) {
					for(int col = 0; col < BOARD_DIM; col++) {
						if(board.getCell(row, col) == BoardTag.BRIG)counter++;
					}
				}
				
				//Check if every ship is on the board
				if(counter == SHIP_QUANTITY_5*5+SHIP_QUANTITY_4*4+SHIP_QUANTITY_3*3+SHIP_QUANTITY_2*2+SHIP_QUANTITY_1 || true){
			        /*
			         * Important notes for client/server team: you need to change the code marked with *, that the enemyboard(on the right hand side)
			         * in GUI.Host window of player1(the host) is updated based on the allieboard in GUI.Guest window of player2(the guest)
			         * and the same rules are applied for ship list of the two players. 
			         * */
		        	//update the state of every cell of the host board in the in game window based on the state of the board
			        //in pre game
					for(int row = 0; row < BOARD_DIM; row++) {
			        	for(int col = 0; col < BOARD_DIM; col++) {
			        		if(board.getCell(row, col) == BoardTag.BRIG) {
			        			Host.getallieBoard().setCell(row, col, BoardTag.BRIG);
			        			((Rectangle)Host.getallieBoardUI().getChildren().get(row*BOARD_DIM+col)).setFill(Color.web("#F5B041"));
			        		}else {
			        			Host.getallieBoard().setCell(row, col, BoardTag.EMPTY);
			        			((Rectangle)Host.getallieBoardUI().getChildren().get(row*BOARD_DIM+col)).setFill(Color.LIGHTSKYBLUE);
			        		}
			        	}
			        }
			        
			        //update the state of every cell of the guest board in the in game window based on the state of the board
			        //in pre game
			        for(int row = 0; row < BOARD_DIM; row++) {
			        	for(int col = 0; col < BOARD_DIM; col++) {
			        		//*
			        		if(Guest_preGame.getBoard().getCell(row, col) == BoardTag.BRIG) {
			        			Host.getenemyBoard().setCell(row, col, BoardTag.BRIG);
//			        			((Rectangle)GUI.Host.getenemyBoardUI().getChildren().get(row*BOARD_DIM+col)).setFill(Color.web("#EC7063"));
			        		}
			        		//*
			        		else {
			        			Host.getenemyBoard().setCell(row, col, BoardTag.EMPTY);
//			        			((Rectangle)GUI.Host.getenemyBoardUI().getChildren().get(row*BOARD_DIM+col)).setFill(Color.LIGHTSKYBLUE);
			        		}
			        	}
			        }
			        
			        //Draw ships in container
			        LinkedList<ShipUI> tempList = Guest_preGame.getShipList();
			        Group newShipGroup = new Group();
			        double tileX = Host.getRightContainer().getTranslateX();
			        double tileY = Host.getRightContainer().getTranslateY();
			        double lastCol = tileX + Host.getRightContainer().getPrefWidth();
			        //*
			        for(int i = 0; i < tempList.size(); i++) {
			        	ShipUI tempShip = new ShipUI();
			        	tempShip.addShipBlocks(tempShip, tempList.get(i).getSize(), tempList.get(i).getDir(),SHIP_BLOCK_SIZE);
			        	if(tileX >= lastCol) {
			        		tileX = Host.getRightContainer().getTranslateX();
			        		tileY += Host.getRightContainer().getPrefHeight()/2;
			        	}

			        	tempShip.setTranslateX(tileX + Host.getRightContainer().getPrefWidth()/20);
			        	tempShip.setTranslateY(tileY + Host.getRightContainer().getPrefHeight()/10);
			        	newShipGroup.getChildren().add(tempShip);
			        	tileX += Host.getRightContainer().getPrefWidth()/5+5;
			        }
			        Host.getRoot().getChildren().add(newShipGroup);
					stage.setScene(toChange);
					stage.setFullScreen(true);
				}else {
					message.setTextFill(Color.web("#DC143C"));
					message.setTranslateX(0);
					message.setText("All ships must be on the board"+"\n"+"(Click)");
				}
			}
			
		});
	}
	
	public static Board getBoard() {
		return board;
	}
	
	public static LinkedList<ShipUI> getShipList(){
		return shipUIList; 
	}
	
	public static Group getRoot() {
		return root;
	}
	
	public static int getBlockSize() {
		return BLOCK_SIZE;
	}
}
