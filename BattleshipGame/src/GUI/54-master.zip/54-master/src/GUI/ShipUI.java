package GUI;

import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class ShipUI extends GridPane {
	private int size;
	private static final int BLOCK_SIZE = 10;
	private static final int BLOCK_STROKE = 1;
	private int ALTERNATIVE_SIZE = Host_preGame.getBlockSize();
	private boolean isVertical;
	int prevCol = -1;
	int prevRow = -1;
	int col;   //x-coordinate of ship on board
	int row;   //y-coordinate of ship on board
	int colchange = 0;
	int rowchange = 0;

	private static Rectangle drawShipBlock(int blockSize) {
		Rectangle block = new Rectangle(0, 0, blockSize, blockSize);
		block.setFill(Color.RED);
		block.setStroke(Color.BLACK);
		block.setStrokeWidth(BLOCK_STROKE);
		return block;
	}
	
	public int getSize() {
		return size;
	}
	
	public boolean getDir() {
		return isVertical;
	}

	public int getBlockResize() {
		return ALTERNATIVE_SIZE;
	}
	
	public void setBlockResize(int value) {
		this.ALTERNATIVE_SIZE = value;
	}

	public static int getBlockSize() {
		return BLOCK_SIZE;
	}
	
	//Attach multiple square to make a ship, whether horizontal or vertical
	public void addShipBlocks(ShipUI shipUI, int size, boolean isVertical,int blockSize) {
		int coorX = 0;
		int coorY = 0;
		int deltaX = 0;
		int deltaY = 0;
		if(isVertical) {
			deltaY += 1;
		}else {
			deltaX += 1;
		}
		for(int i = 0; i < size; i ++) {
			Rectangle block = new Rectangle();
			block = drawShipBlock(blockSize);
			shipUI.add(block, coorX, coorY);
			coorX += deltaX;
			coorY += deltaY;
		}
	}	
	
	//Create ship with variable length
	public ShipUI createShip(int shipSize, boolean isVertical,int blockSize) {
		ShipUI shipUI = new ShipUI();
		shipUI.size = shipSize;
		shipUI.isVertical = isVertical;
		addShipBlocks(shipUI, shipSize,isVertical,blockSize);
		return shipUI;
	}

	//Detect drag action on a ship
	public void addDragAndDrop(Board board, BoardUI boardUI, Pane container, double coorX, double coorY) {
		final Vector2dDouble vector2dDouble = new Vector2dDouble();
		setOnDragDetected(mouseEvent -> {
			startFullDrag();
		});
		
		//call when mouse is pressed
		setOnMousePressed(mouseEvent -> {
			setMouseTransparent(true);
			vector2dDouble.setX(mouseEvent.getSceneX());
			vector2dDouble.setY(mouseEvent.getSceneY());
			if(mouseEvent.isSecondaryButtonDown())
			{
				for(int Row = 0; Row < board.getDim(); Row++) {
					for(int Col = 0; Col < board.getDim(); Col++) {
						if(Row == prevRow && Col == prevCol) {
							for(int d = 0; d < size; d++) {
								if(isVertical) {
									board.setCell(Row+d, Col, BoardTag.EMPTY);
								}else {
									board.setCell(Row, Col+d, BoardTag.EMPTY);
								}
							}

						}
					}
				}
				if(this.getRotate() == 90.0)
				{
					this.setRotate(0);
					switch (size){
						case 2: this.rowchange = -1; break;
						case 3: this.rowchange = -1; this.colchange = 1; break;
						case 4: this.rowchange = -2; this.colchange = 1; break;
						case 5: this.rowchange = -2; this.colchange = 2; break;

					}

					int x = 0;
					int y = 0;
					switch (this.size){
						case 5: x = 2;  y = -2; break;
						case 4: x = 1;  y = -2; break;
						case 3: x = 1;  y = -1; break;
						case 2:			y = -1; break;
					}
					setTranslateX(getTranslateX() + (x * ALTERNATIVE_SIZE));
					setTranslateY(getTranslateY() + (y * ALTERNATIVE_SIZE));

				} else {
					this.setRotate(90);
					switch (size){
						case 2: this.rowchange = 1; break;
						case 3: this.rowchange = 1; this.colchange = -1; break;
						case 4: this.rowchange = 2; this.colchange = -1; break;
						case 5: this.rowchange = 2; this.colchange = -2; break;

					}
					int x = 0;
					int y = 0;
					switch (this.size){
						case 5: x = -2; y = 2; break;
						case 4: x = -1; y = 2; break;
						case 3: x = -1; y = 1; break;
						case 2: 		y = 1; break;
					}
					setTranslateX(getTranslateX() + (x * ALTERNATIVE_SIZE));
					setTranslateY(getTranslateY() + (y * ALTERNATIVE_SIZE));

				}
				col = (int) Math.floor((getTranslateX() - boardUI.getTranslateX()) / ALTERNATIVE_SIZE) ;
				row = (int) Math.floor((getTranslateY() - boardUI.getTranslateY()) / ALTERNATIVE_SIZE) ;
				System.out.printf("%d,%d ", this.row, this.col);
				this.isVertical = !this.isVertical;
				this.prevCol = this.col;
				this.prevRow = this.row;

/*				if (this.getRotate() == 90)
				{
					int x = 0;
					int y = 0;
					switch (this.size){
						case 5: x = -2; y = 2; break;
						case 4: x = -1; y = 2; break;
						case 3: x = -1; y = 1; break;
						case 2: y = 1; break;
					}
					setTranslateX(getTranslateX() + (x * ALTERNATIVE_SIZE));
					setTranslateY(getTranslateY() + (y * ALTERNATIVE_SIZE));
				}*/
			}
		});
		
		//call when mouse is released
		setOnMouseReleased(mouseEvent -> {

			detectOnBoard(board,boardUI, prevCol, prevRow);
			setMouseTransparent(false);
		});

		//call when mouse is dragged
		setOnMouseDragged(mouseEvent -> {
			double mouseX = mouseEvent.getSceneX();
			double mouseY = mouseEvent.getSceneY();
			double deltaX = mouseX - vector2dDouble.getX();
			double deltaY = mouseY - vector2dDouble.getY();
			setTranslateX(getTranslateX() + deltaX);
			setTranslateY(getTranslateY() + deltaY);


			//If ship leaves the container, it will be resized to match the size of board cells. 
			//If not, it returns to normal size
			if(getTranslateX() < coorX) {
				
				//check if ship is on the board. If yes, its coordinates will be set to coordinates of board
				if (getTranslateX() > boardUI.getTranslateX()
						&& getTranslateY() > boardUI.getTranslateY()
						&& getTranslateX() < boardUI.getTranslateX()+Host_preGame.BOARD_DIM*BoardUI.BLOCK_WIDTH
						&& getTranslateY() < boardUI.getTranslateY()+Host_preGame.BOARD_DIM*BoardUI.BLOCK_HEIGHT) {
					col = (int) Math.floor((getTranslateX() - boardUI.getTranslateX()) / ALTERNATIVE_SIZE + colchange);
					row = (int) Math.floor((getTranslateY() - boardUI.getTranslateY()) / ALTERNATIVE_SIZE + rowchange);
				}
				
				//Scale ship
				for(int a = 0; a < size; a++) {
					 setBlockResize(25);
					((Rectangle)getChildren().get(a)).setWidth(25);
					((Rectangle)getChildren().get(a)).setHeight(25);
				}
			}else {
				for(int a = 0; a < size; a++) {
					((Rectangle)getChildren().get(a)).setWidth(getBlockSize());
					((Rectangle)getChildren().get(a)).setHeight(getBlockSize());

				}
			}
			vector2dDouble.setX(mouseX);
			vector2dDouble.setY(mouseY);
		});
	}
	
	//Check if the ships are legally placed on the board.
	//Counter represents number of correctly placed blocks of ship.
	//If counter is equal to ship size, the ship is legally placed.
	public int checkValid(BoardUI boardUI, Board board, int Row, int Col, boolean vertical, int boardSize) {
		int counter = 0;

		for(int d = 0; d < boardSize; d++) {
			if(vertical) {
				if (getTranslateX() > boardUI.getTranslateX()
						&& getTranslateY() > boardUI.getTranslateY()
						&& getTranslateX() < boardUI.getTranslateX()+Host_preGame.BOARD_DIM*ALTERNATIVE_SIZE
						&& getTranslateY()+getBlockResize()*(size-1) < boardUI.getTranslateY()+Host_preGame.BOARD_DIM*ALTERNATIVE_SIZE) {
					if(board.getCell(Row+d, Col) == BoardTag.EMPTY) {
						counter++;
					}
				}
			}else {
				if (getTranslateX() > boardUI.getTranslateX()
						&& getTranslateY() > boardUI.getTranslateY()
						&& getTranslateX()+getBlockResize()*(size-1) < boardUI.getTranslateX()+Host_preGame.BOARD_DIM*ALTERNATIVE_SIZE
						&& getTranslateY() < boardUI.getTranslateY()+Host_preGame.BOARD_DIM*ALTERNATIVE_SIZE) {
					if(board.getCell(Row, Col+d) == BoardTag.EMPTY) {
						counter++;
					}
				}				
			}
		}
		return counter;
	}

	/*Detect coordinates of a ship on the board. It will take the form (col,row) in which the far left corner be (0,0).
    	If the ship is vertical, the y coordinate will change along with the size of the ship, ex. ((0,0),(0,1),(0,2)),
    	which represents a vertical ship of size 3 at cells (0,0),(0,1),(0,2). The same rules are applied for the horizontal
    	ships but the x coordinate will change.

    	The cell which contains the ship is set to BRIG. If the ship is relocated, the previous location of the ship on the board will be set to EMPTY.
	 */
	public void detectOnBoard(Board board,BoardUI boardUI, int prevcol, int prevrow) {
		if (getTranslateX() > boardUI.getTranslateX()
				&& getTranslateY() > boardUI.getTranslateY()
				&& getTranslateX() < boardUI.getTranslateX()+Host_preGame.BOARD_DIM*25
				&& getTranslateY() < boardUI.getTranslateY()+Host_preGame.BOARD_DIM*25) {
			
			//prevCol & prevRow = -1 means the ship is either not on the board or is not legally placed
			if(prevCol == -1 && prevRow == -1) {				
				//Iterate through every cell
				for(int Row = 0; Row < board.getDim(); Row++) {
					for(int Col = 0; Col < board.getDim(); Col++) {
						//if the first block of ship enters a cell
						if(Row == row && Col == col) {
							//check ship position
							int counter = checkValid(boardUI,board,Row,Col,isVertical,size);
							//set all cells which contain ship's blocks to GUI.BoardTag.BRIG
							for(int d = 0; d < size; d++) {
								if(isVertical) {
									if(Host_preGame.BOARD_DIM-row >= size && counter == size) {
										board.setCell(Row+d, Col, BoardTag.BRIG);
										prevCol = col;
										prevRow = row;
									}
								}else {
									if(Host_preGame.BOARD_DIM-col >= size && counter == size) {
										board.setCell(Row, Col+d, BoardTag.BRIG);
										prevCol = col;
										prevRow = row;
									}
								}
							}
						}
					}
				}
			}
			//if ship is relocated
			else {
				//reset cells which contain previous position of ship to GUI.BoardTag.EMPTY
				for(int Row = 0; Row < board.getDim(); Row++) {
					for(int Col = 0; Col < board.getDim(); Col++) {
						if(Row == prevRow && Col == prevCol) {
							for(int d = 0; d < size; d++) {
								if(isVertical) {
									if (Row + d < board.getDim())
										board.setCell(Row+d, Col, BoardTag.EMPTY);
								}else {
									if (Col + d < board.getDim())
										board.setCell(Row, Col+d, BoardTag.EMPTY);
								}
							}

						}
					}
				}
				//then set cells which are ships's new position to GUI.BoardTag.Brig
				for(int Row = 0; Row < board.getDim(); Row++) {
					for(int Col = 0; Col < board.getDim(); Col++) {
						if(Row == row && Col == col) {
							int counter = checkValid(boardUI,board,Row,Col,isVertical,size);
							for(int d = 0; d < size; d++) {
								if(isVertical) {
									if(counter == size) {
										if(Host_preGame.BOARD_DIM-row >= size) {
											board.setCell(Row+d, Col, BoardTag.BRIG);
											prevCol = col;
											prevRow = row;
										}
										//in case ships's position is illegal, reset prevCol and prevRow to -1
										else {
											prevCol = -1;
											prevRow = -1;
										}
									}									
								}else {
									if(counter == size) {
										if(Host_preGame.BOARD_DIM-col >= size) {
											board.setCell(Row, Col+d, BoardTag.BRIG);
											prevCol = col;
											prevRow = row;
										}else {
											prevCol = -1;
											prevRow = -1;
										}
									}
									
								}
							}
						}
					}
				}
			}

//			for(int Row = 0; Row < board.getDim(); Row++) {
//				for(int Col = 0; Col < board.getDim(); Col++) {
//					if(board.getCell(Row, Col) == GUI.BoardTag.BRIG) {
//						System.out.println("Ship: column= "+Col+"|row="+Row);
//					}
//				}
//			}
		}
	}
}
