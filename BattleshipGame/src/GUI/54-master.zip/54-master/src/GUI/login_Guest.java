package GUI;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class login_Guest {
	private static Group layout;
	private static Text txt1;
	private static Text txt2;
	private static Text txt3;
	private static Text txt4;
	private static Text txt5;
	private static TextField inputPort;
	private static TextField inputIP;
	private static TextField inputName;
	private static Circle host;
	private static Circle guest;
	private static Text info;
//	private static Button next;
	
	public void set() {
		txt1 = new Text("HOST");
		txt2 = new Text("GUEST");
		txt3 = new Text("Port of Host");
		txt4 = new Text("IP of Host");
		txt5 = new Text("Name");
		inputPort = new TextField();
		inputIP = new TextField();
		inputName = new TextField();
		host = new Circle();
		guest = new Circle();
		info = new Text("*Please provide valid data");
//		next = new Button("Next -->");
		layout = new Group();
		
		txt1.setTranslateX(70);
		txt1.setTranslateY(75);
		txt1.setFont(Font.font("Copperplate Gothic Light", 30));
		txt1.setFill(Color.web("#FEFCFF"));
		
		txt2.setTranslateX(335);
		txt2.setTranslateY(75);
		txt2.setFont(Font.font("Copperplate Gothic Light", 30));
		txt2.setFill(Color.web("#FEFCFF"));
		
		txt3.setTranslateX(75);
		txt3.setTranslateY(165);
		txt3.setFont(Font.font("Microsoft YaHei UI Light", 25));
		txt3.setFill(Color.web("#FEFCFF"));
		
		txt4.setTranslateX(100);
		txt4.setTranslateY(215);
		txt4.setFont(Font.font("Microsoft YaHei UI Light", 25));
		txt4.setFill(Color.web("#FEFCFF"));
		
		txt5.setTranslateX(155);
		txt5.setTranslateY(265);
		txt5.setFont(Font.font("Microsoft YaHei UI Light", 25));
		txt5.setFill(Color.web("#FEFCFF"));
		
		inputPort.setPrefSize(321, 25);
		inputPort.setTranslateX(226);
		inputPort.setTranslateY(145);
		inputPort.setStyle("-fx-focus-color: transparent;"+
				"-fx-faint-focus-color: transparent");
		
		inputIP.setPrefSize(321, 25);
		inputIP.setTranslateX(226);
		inputIP.setTranslateY(195);
		inputIP.setStyle("-fx-focus-color: transparent;"+
				"-fx-faint-focus-color: transparent");
		
		inputName.setPrefSize(321, 25);
		inputName.setTranslateX(226);
		inputName.setTranslateY(245);
		inputName.setStyle("-fx-focus-color: transparent;"+
				"-fx-faint-focus-color: transparent");
		
		guest.setRadius(10);
		guest.setCenterX(txt2.getTranslateX()+txt2.getLayoutBounds().getWidth()+guest.getRadius()*2);
		guest.setCenterY(txt2.getTranslateY()-10);
		guest.setFill(Color.LAWNGREEN);
        guest.setStroke(Color.TRANSPARENT);
        guest.setStrokeWidth(1);
		
		host.setRadius(10);
		host.setCenterX(txt1.getTranslateX()+txt1.getLayoutBounds().getWidth()+host.getRadius()*2);
		host.setCenterY(txt1.getTranslateY()-10);
		host.setFill(Color.WHITE);
        host.setStroke(Color.TRANSPARENT);
        host.setStrokeWidth(1);
        
		info.setTranslateX(200);
		info.setTranslateY(300);
		info.setFill(Color.web("#FEFCFF"));
		info.setFont(Font.font("Impact", 15));        
		
		layout.getChildren().addAll(txt1,txt2,txt3,txt4,txt5,inputPort,inputIP,inputName,guest,host,info);
	}
	
//	public Button getNextBTN() {
//		return next;
//	}
	
	public void changeScreen(Stage stage, Scene toChange) {
	    getLayout().setOnKeyPressed(new EventHandler<KeyEvent>()
	    {
	        @Override
	        public void handle(KeyEvent e)
	        {
	        	
	        	if (e.getCode().equals(KeyCode.ENTER)){
	        			if(getinputPort().getText().isEmpty() || getinputIP().getText().isEmpty()) {
	    	        		getInfo().setText("*Please input valid information");
	    	        	}else {
	    	        		getInfo().setText("");
	    	        		Host.getGuestName().setText(getinputName().getText().isEmpty() ? "Player 2" : getinputName().getText());
	    	        		Guest.getGuestName().setText(getinputName().getText().isEmpty() ? "Player 2" : getinputName().getText());
	    	        		stage.setScene(toChange);
	    	        	}
	        		}
	        	}
	    });
	}
	
	public Text getInfo() {
		return info;
	}
	
	public static TextField getinputPort() {
		return inputPort;
	}
	
	public static TextField getinputIP() {
		return inputIP;
	}
	
	public static TextField getinputName() {
		return inputName;
	}

	public static Group getLayout() {
		return layout;
	}
}
