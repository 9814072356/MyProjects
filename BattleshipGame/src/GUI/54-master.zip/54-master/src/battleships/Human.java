/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleships;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Human implements Player{
    
    public static Scanner scan = new Scanner(System.in);
    
    Ship[] shipPlacement = new Ship[10];
    char[][] shots = new char[10][10];
    
    
    
    @Override
    public void initialize(){

        printShipField();
        System.out.println("Place your Carrier! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(5, "Carrier", 0);
        printShipField();

        System.out.println("Place your first Battleship! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(4, "Battleship", 1);
        printShipField();

        System.out.println("Place your second Battleship! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(4, "Battleship", 2);
        printShipField();

        System.out.println("Place your first Cruiser! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(3, "Cruiser", 3);
        printShipField();

        System.out.println("Place your second Cruiser! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(3, "Cruiser", 4);
        printShipField();

        System.out.println("Place your third Cruiser! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(3, "Cruiser", 5);
        printShipField();

        System.out.println("Place your first Destroyer! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(2, "Destroyer", 6);
        printShipField();

        System.out.println("Place your second Destroyer! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(2, "Destroyer", 7);
        printShipField();

        System.out.println("Place your third Destroyer! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(2, "Destroyer", 8);
        printShipField();

        System.out.println("Place your fourth Destroyer! A-J, 0-9, [u]p, [d]own, [l]eft, [r]ight, format A0d");
        shipInput(2, "Destroyer", 9);
        printShipField();

        for (int i  = 0; i  < 10; i++){
            for (int j = 0; j < 10; j++){
                shots[i][j] = '_';
            }
        }

    }

    
    
    
    public int[] action(){
        return null;
    }
    
    public void sendData(){
    }
    
    public char getSpace(int x, int y){


        return shots[y][x];
    }
    
    public boolean validSpace(int x, int y){

        return shots[y][x] == '_';
    }
    
    public void setSpace(int x, int y, boolean z){
        if (z) {
            shots[y][x] = 'O';
        } else {
            shots[y][x] = 'X';
        }
    }
    
    
    private void placeShip(int x, int y, char d, int shipLength, int pos, String n) throws Exception{
        switch (d){
            case 'u':
                if (validShip(x, y, 0, -1, shipLength)) {
                    placeShipHelper(x, y, 0, -1, shipLength, pos, n);
                } else {
                    throw new Exception();
                }
                break;
            case 'd':
                if (validShip(x, y, 0, 1, shipLength)) {
                    placeShipHelper(x, y, 0, 1, shipLength, pos, n);
                } else {
                    throw new Exception();
                }
                break;
            case 'r':
                if (validShip(x, y, 1, 0, shipLength)) {
                    placeShipHelper(x, y, 1, 0, shipLength, pos, n);
                } else {
                    throw new Exception();
                }
                break;
            case 'l':
                if (validShip(x, y, -1, 0, shipLength)) {
                    placeShipHelper(x, y, -1, 0, shipLength, pos, n);
                } else {
                    throw new Exception();
                }
                break;

        }
    }

    private boolean validShip(int x, int y, int xd, int yd, int shipLength) {
        for (int i = 0; i < shipLength; i++){

            if (x + i * xd > 9 || x + i*xd < 0) {
                return false;
            }
            if (y + i * yd > 9 || y + i * yd < 0) {
                return false;
            }
            for (int j = 0; j < 10; j++){
                if (shipPlacement[j] != null){
                    for (int k = 0; k < shipPlacement[j].getLength(); k++){

                        // System.out.println(shipPlacement[j].getCoords(k)[0] == x + i*xd && shipPlacement[j].getCoords(k)[1] == y + i*yd);
                        if (shipPlacement[j].getCoords(k)[0] == x + i*xd && shipPlacement[j].getCoords(k)[1] == y + i*yd){

                            return false;
                        }
                    }
                } else {
                    break;
                }
            }

        }



        return true;
    }

    private void placeShipHelper(int x, int y , int xd, int yd, int shipLength, int pos, String n){
        shipPlacement[pos] = new Ship(shipLength, x, y, xd, yd, n);

    }


    private void shipInput(int shipLength, String n, int position) {
        while (true) {
            int x = 10;
            int y = 10;
            char d = 'Q';
            String z = scan.next();
            z = z.toLowerCase();
            char[] p = z.toCharArray();

            if (p.length < 3) {
                System.out.println("Invalid Input! Try Again!");
                printShipField();
            } else {


                if (p[0] - 'a' >= 0 && p[0] - 'a' < 'k') {
                    x = p[0] - 'a';

                }


                if (p[1] - '0' >= 0 && p[1] - '0' < 10) {
                    y = p[1] - '0';
                }


                if (p[2] == 'u' || p[2] == 'd' || p[2] == 'l' || p[2] == 'r') {
                    d = p[2];
                }

                if (x != 10 && y != 10 && d != 'Q') {
                    try {
                        placeShip(x, y, d, shipLength, position, n);

                    } catch (Exception e) {
                        System.out.println("Invalid input! Try again!");
                        printShipField();

                    }
                } else {
                    System.out.println("Invalid input! Try Again!");
                    printShipField();
                }

                if (shipPlacement[position] != null) {
                    break;
                }
            }

        }
    }
    private void printShipField(){
        System.out.println("Your Ship Placements:");
        System.out.println(" |A|B|C|D|E|F|G|H|I|J");
        for (int i = 0; i < 10; i++){
            System.out.print(i + "|");
            for (int j = 0; j < 10; j++){
                boolean test = false;
                for (int k = 0; k < 10; k++){

                    if (shipPlacement[k] != null){
                        for (int l = 0; l < shipPlacement[k].getLength(); l++){
                            test = shipPlacement[k].isShipPosition(j, i, l);
                            if ( test) {
                                break;
                            }
                        }
                        if (test) {
                            break;
                        }
                    } else {
                        break;
                    }
                }
                if (!test) {
                    System.out.print("_");
                } else {
                    System.out.print("S");
                }
                System.out.print("|");
            }
            System.out.println();

        }

    }


    public Ship getShip(int i){
        return shipPlacement[i];
    }

    public boolean lost(){
        for (int i = 0; i < 10; i++){
            if (!shipPlacement[i].isSunk() ){
                return false;
            }
        }
        return true;
    }

}
