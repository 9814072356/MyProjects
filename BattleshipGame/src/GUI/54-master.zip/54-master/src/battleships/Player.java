/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleships;

/**
 *
 * @author user
 */
public interface Player {
    
    
     void initialize();
    
     int[] action();
    
     void sendData();
    
     char getSpace(int x, int y);
    
     boolean validSpace(int x, int y);
    
     void setSpace(int x, int y, boolean z);
    
    Ship getShip(int i);

    boolean lost();
    
}
