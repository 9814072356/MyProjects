package battleships;

public class Ship {

    int length;
    int[] xCoords;
    int[] yCoords;
    String name;


    public Ship( int l, int x, int y, int xd, int yd, String n){
        length = l;
        xCoords = new int[l];
        yCoords = new int[l];
        xCoords[0] = x;
        yCoords[0] = y;
        name = n;

        for (int i = 0; i < l; i++){
            xCoords[i] = x + i*xd;
            yCoords[i] = y + i*yd;

        }



    }

    public int[] getCoords(int pos){
        int[] x = new int[2];
        x[0] = xCoords[pos];
        x[1] = yCoords[pos];

        return x;
    }

    public void hit(int pos){
        xCoords[pos] = 10;
        yCoords[pos] = 10;
    }

    public boolean isSunk(){
        for (int i = 0; i < length; i++){
            if (xCoords[i] != 10 && yCoords[i] != 10){
                return false;
            }
        }
        return true;
    }

    public int getLength() {
        return length;
    }

    public boolean isShipPosition(int x, int y, int pos){
        return (x == xCoords[pos] && y == yCoords[pos]);
    }

    public String getType(){
        return name;
    }
}
