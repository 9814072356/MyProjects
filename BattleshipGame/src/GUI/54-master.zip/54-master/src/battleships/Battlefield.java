/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleships;

/**
 *
 * @author user
 */
public class Battlefield {
    
    private Player player1;
    private Player player2;

    private int currentPlayerNumber = 1;
    
    public void Attack(int xCoord, int yCoord) throws Exception   {
        if (currentPlayerNumber == 1) {
            if (player1.validSpace(xCoord, yCoord)){
                for (int i = 0; i < 10; i++){
                    for (int j = 0; j < player2.getShip(i).getLength(); j++){
                        if (player2.getShip(i).getCoords(j)[0] == yCoord && player2.getShip(i).getCoords(j)[1] == xCoord){
                            player1.setSpace(xCoord, yCoord, true);
                            player2.getShip(i).hit(j);
                            System.out.println("It's a hit!");
                            if (player2.getShip(i).isSunk()){
                                System.out.println("You sunk a " + player2.getShip(i).getType()+ "!");
                            }
                            break;
                        }
                    }
                }
                if (player1.getSpace(xCoord, yCoord) == '_'){
                    player1.setSpace(xCoord, yCoord, false);
                    System.out.println("It's a miss!");
                }
            } else {
                throw new Exception();
            }
        
        
        } else {
            if (player2.validSpace(xCoord, yCoord)){
                for (int i = 0; i < 10; i++){
                    for (int j = 0; j < player1.getShip(i).getLength(); j++){
                        if (player1.getShip(i).getCoords(j)[0] == yCoord && player1.getShip(i).getCoords(j)[1] == xCoord){
                            player2.setSpace(xCoord, yCoord, true);
                            player1.getShip(i).hit(j);
                            System.out.println("It's a hit!");
                            if (player1.getShip(i).isSunk()){
                                System.out.println("You sunk a " + player1.getShip(i).getType()+ "!!!");
                            }
                            break;
                        }
                    }
                }
                if (player2.getSpace(xCoord, yCoord) == '_'){
                    player2.setSpace(xCoord, yCoord, false);
                    System.out.println("It's a miss!");
                }
            } else {
                throw new Exception();
            }
        
        
        }
    }
    
    public Battlefield(Player p1, Player p2){
        player1 = p1;
        player2 = p2;
    }
    
    public void initializePlayers(){
        player1.initialize();
        player2.initialize();
        
    }
    
    public void printBattleField(){
        System.out.println("The Battlefield:");
        System.out.println(" |A|B|C|D|E|F|G|H|I|J||A|B|C|D|E|F|G|H|I|J");
        for (int i = 0; i < 10; i++){
            System.out.print(i + "|");
            for (int j = 0; j < 10; j++){
                System.out.print(player1.getSpace(i, j) + "|");
            }
            System.out.print("|");
            for (int j = 0; j < 10; j++){
                System.out.print(player2.getSpace(i, j) + "|");
            }
            System.out.println();

        }
        System.out.println("Currently, it is Player "+ currentPlayerNumber + "'s turn");
        System.out.println("Fire a Shot! Format: A0");





    }
    
    public void togglePlayerNumber(){
        if (currentPlayerNumber == 1) {
            currentPlayerNumber = 2;
        } else {
            currentPlayerNumber = 1;
        }
    }

    public boolean victoryCheck(){
        if (currentPlayerNumber == 1){
            return player2.lost();
        } else {
            return player1.lost();
        }
    }
    
}
