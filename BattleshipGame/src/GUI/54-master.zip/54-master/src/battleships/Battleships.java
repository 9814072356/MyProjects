/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleships;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Battleships {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        Battlefield game = new Battlefield(new Human(), new Human());

        game.initializePlayers();
        game.printBattleField();

        while (scan.hasNextLine()) {
            String z = scan.next();
            z = z.toLowerCase();
            char[] b = z.toCharArray();
            int x = 10;
            int y = 10;

            if (b.length < 2) {
                System.out.println("Invalid Input! Try again!");
            } else {

                if (b[0] - 'a' >= 0 && b[0] - 'a' < 'k') {
                    x = b[0] - 'a';

                }


                if (b[1] - '0' >= 0 && b[1] - '0' < 10) {
                    y = b[1] - '0';
                }

                if (x != 10 && y != 10) {
                    try {
                        game.Attack(y, x);
                        if (game.victoryCheck()) {
                            System.out.println("Congratulations! You have won!");
                            break;
                        }
                        game.togglePlayerNumber();

                    } catch (Exception e) {
                        System.out.println("Invalid target!");
                    }

                } else {
                    System.out.println("Invalid target");
                }
                game.printBattleField();

            }

        }

    }
}