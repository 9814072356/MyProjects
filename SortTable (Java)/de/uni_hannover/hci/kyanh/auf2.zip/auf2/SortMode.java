package de.uni_hannover.hci.kyanh.auf2;
public enum SortMode{
    INFO,PRICE,ID;
}