package de.uni_hannover.hci.kyanh.auf2;
public interface ISortTable{
    String getSortString(SortMode mode);
    void print();
}